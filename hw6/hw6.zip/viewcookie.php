<?php 
if(isset($_COOKIE["username2"])) { 
	echo "The new cookie <b>username2</b> contains the value " . $_COOKIE["username2"];
}
?>
